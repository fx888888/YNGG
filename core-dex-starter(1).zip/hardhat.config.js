require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

const PRIVATE_KEY = process.env.PRIVATE_KEY || "";
const accounts = PRIVATE_KEY ? [PRIVATE_KEY] : [];

module.exports = {
  solidity: {
    version: "0.8.24",
    settings: {
      optimizer: { enabled: true, runs: 800 }
    }
  },
  networks: {
    core_mainnet: {
      url: "https://rpc.coredao.org",
      chainId: 1116,
      accounts
    },
    core_testnet: {
      url: "https://rpc.test.btcs.network", // Core testnet RPC (commonly used)
      chainId: 1115,
      accounts
    }
  }
};