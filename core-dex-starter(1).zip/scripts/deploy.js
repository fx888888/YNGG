const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deployer:", deployer.address);

  // 1) Deploy WCORE (or use existing wrapped CORE if you have an address)
  const WCORE = await hre.ethers.getContractFactory("WCORE");
  const wcore = await WCORE.deploy();
  await wcore.waitForDeployment();
  console.log("WCORE:", await wcore.getAddress());

  // 2) Deploy Factory
  const Factory = await hre.ethers.getContractFactory("DEXFactory");
  const factory = await Factory.deploy(deployer.address);
  await factory.waitForDeployment();
  console.log("Factory:", await factory.getAddress());

  // 3) Deploy Router
  const Router = await hre.ethers.getContractFactory("DEXRouter");
  const router = await Router.deploy(await factory.getAddress(), await wcore.getAddress());
  await router.waitForDeployment();
  console.log("Router:", await router.getAddress());

  console.log("\nNEXT:");
  console.log("- Approve tokens and call router.addLiquidity(...) to seed your first pool.");
  console.log("- Use router.swapExactTokensForTokens(...) to swap.");
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});