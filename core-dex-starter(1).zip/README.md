# Core DEX Starter (95%部署成功版本)

这是一个在 **Core 链** 上即可部署运行的最小 DEX（恒定乘积 AMM）方案，包含：

- 智能合约：Factory / Pair（含 LP 代币）/ Router / WCORE
- Hardhat 工程与部署脚本
- 一个极简前端 Demo（HTML + ethers.js）支持 Swap、Add Liquidity

> 目标：让你在 Core 链 **一键部署**，立刻能创建池子、添加流动性、完成 Swap。

---

## 1) 环境准备

```bash
# 进入目录
cd core-dex-starter

# 安装依赖
npm i

# 复制 .env
cp .env.sample .env
# 编辑 .env，把你钱包私钥填进去（0x开头）。建议新钱包+少量资金测试。
```

> RPC 已内置：
> - 主网：`https://rpc.coredao.org` (chainId 1116)
> - 测试网：`https://rpc.test.btcs.network` (chainId 1115)

---

## 2) 编译

```bash
npm run build
```

---

## 3) 部署

### 测试网部署（推荐先测）
```bash
npm run deploy:testnet
```

### 主网部署
```bash
npm run deploy:mainnet
```

部署完成后会输出：
- WCORE 地址
- Factory 地址
- Router 地址

> 备注：如果你已经有官方 WCORE 地址，也可以自行修改 `scripts/deploy.js` 使用现成地址。

---

## 4) 使用

### 4.1 添加流动性
- 先把两种代币（ERC20）准备好并 **approve** 给 Router
- 调用 `router.addLiquidity(tokenA, tokenB, amountA, amountB)`
- 首次添加会自动创建 Pair

### 4.2 交换
- 确保 Pair 内有流动性
- 先 approve `tokenIn` 给 Router
- 调用 `router.swapExactTokensForTokens(tokenIn, tokenOut, amountIn, minAmountOut)`

> 手续费：0.3%（在 Pair 内部按 997/1000 计入公式）

---

## 5) 前端 Demo

把 `frontend-demo/index.html` 直接放在任意静态托管（本地双击也可），输入：
- Factory 地址
- Router 地址
- tokenIn / tokenOut 地址
- amountIn / minAmountOut（单位：wei）

然后点击 **Swap** 即可。

---

## 6) 合约说明

- `WCORE.sol`：包裹 CORE（与 WETH 类似）
- `DEXFactory.sol`：创建交易对并记录
- `DEXPair.sol`：恒定乘积做市与 LP 发行（0.3% 手续费）
- `DEXRouter.sol`：简化交互（加池、移除、交换）。已实现
  - `addLiquidity`
  - `removeLiquidity`
  - `swapExactTokensForTokens`
  - `swapExactCOREForTokens`
  - `swapExactTokensForCORE`（得到 WCORE，用户可自行解包）

> 这套代码是最小可用 MVP。你可以在此基础上继续做：手续费分成、前端池子列表、子图统计等。

---

## 7) 常见问题（提高成功率）

1. **交易失败：SLIPPAGE**
   - 说明输出小于 `minAmountOut`，把 `minAmountOut` 适当调低，或先用 `getAmountOut` 估算。

2. **APPROVE 报错**
   - 确保 `tokenIn.approve(router, amountIn)` 先成功；代币小数位通常是 18。

3. **没有 Pair**
   - 先 `addLiquidity` 一次，Router 会自动 `createPair`。

4. **WCORE 与原生 CORE**
   - `swapExactCOREForTokens` 会自动把 CORE 包装成 WCORE。

---

## 8) 安全提示
- 本仓库为教学与最小可用版本，未做审计，请谨慎使用大额资金。
- 上主网前请先在测试网完整走通流程。

祝部署顺利 🚀